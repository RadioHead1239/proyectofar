/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNegocio;


/**
 *
 * @author el_ca
 */
public class MetodosProductos {
    
    public String HallarCodigo(String Producto, String Presentacion, String Concentracion){
       return ""+(Producto.substring(0, 1) + Presentacion.substring(0, 1) + Concentracion.substring(0, 1)).toUpperCase();
   }
    
}
