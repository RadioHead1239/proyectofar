/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNegocio;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JComboBox;

/**
 *
 * @author el_ca
 */
public class MetodosFarmacia {
    
    
     public void llenarProveedor(JComboBox cboProveedor){
        String []Proveedor={"Victor Evangelista Cucho","Noe Taquiri","Solitario Pe"};
        for (String es:Proveedor){
            cboProveedor.addItem(es);
        }
    }
     
    public double hallarRuc(String proveedor) {
       long ruc = 0;
       if (proveedor.equals("Victor Evangelista Cucho")) {
           ruc = 10774478349L;
       } else if (proveedor.equals("Noe Taquiri")) {
           ruc = 10931234510L;
       } else if (proveedor.equals("Solitario Pe")) {
           ruc = 10235123591L;
       }
       return ruc;
}
     
    
    
}