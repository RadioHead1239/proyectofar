/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNegocio;


import Modelo.Conexion;
import Modelo.Productos;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;


/**
 *
 * @author el_ca
 */
public class ConsultaProducto {
    
    public ArrayList <Productos> getProducto()
    {
        Connection con = Conexion.getConexion();
        Statement stmt;
        ResultSet rs;
        ArrayList<Productos> listaClientes = new ArrayList<>();
        
        try{
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT Producto FROM productos;");
        
        while(rs.next())
        {          
            Productos producto  = new Productos();
            producto.Producto = rs.getString("Producto");
            listaClientes.add(producto);
        }
      
        }catch(Exception e){
          e.printStackTrace();
        }
        return listaClientes;   
    }
    
    
    public Productos getProductoID(String ID)
    {
        Productos producto = new Productos();
        Connection con = Conexion.getConexion();
        Statement stmt;
        ResultSet rs;
   
        try{
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT  *  From productos where ID = " +"'"+ ID +"'");
       
        while(rs.next())
        {
          producto.ID = rs.getString("ID");
          producto.Producto = rs.getString("Producto");
          producto.Presentacion = rs.getString("Concentracion");
          producto.Stock = rs.getInt("Stock");
          producto.Costo = rs.getDouble("Costo");
        }
        }catch(Exception e){
          e.printStackTrace();
        }
        return producto;   
    }
    
    public ArrayList <Productos>  getProductoNombre(String nombre)
    {
        Productos producto = new Productos();
        Connection con = Conexion.getConexion();
        Statement stmt;
        ResultSet rs;
       ArrayList<Productos> lisaProducto = new ArrayList<>();
        try{
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT  *  From productos where producto like " +"'%"+ nombre +"%'");

        while(rs.next())
        {
            producto = new Productos();
          producto.ID = rs.getString("ID");
          producto.Producto = rs.getString("Producto");
          producto.Presentacion = rs.getString("Concentracion");
          producto.Stock = rs.getInt("Stock");
          producto.Costo = rs.getDouble("Costo");
          lisaProducto.add(producto);

        }
        }catch(Exception e){
          e.printStackTrace();
        }
        return lisaProducto;   
    }
}
