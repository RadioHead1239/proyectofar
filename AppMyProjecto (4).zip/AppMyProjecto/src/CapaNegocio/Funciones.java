/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CapaNegocio;

import Modelo.Conexion;
import Modelo.Productos;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author el_ca
 */
public class Funciones {
    
    Statement st;
    ResultSet rs;
    
      public  void LlenarDataTable(DefaultTableModel tableModel,ArrayList<Productos> listaProductos ){
        
        Object[] producto = new Object[6]; 
         
          for (int i = 0; i < listaProductos.size(); i++) {
             producto[0]= listaProductos.get(i).ID.toString();
            producto[1] =  listaProductos.get(i).Producto.toString();
            producto[2] = listaProductos.get(i).Presentacion.toString(); 
            producto[3] = listaProductos.get(i).Concentracion.toString();
            producto[4] = listaProductos.get(i).Stock;
            producto[5] = listaProductos.get(i).Costo;
            tableModel.addRow(producto);
        }
         
         
    }
    
public  ArrayList<Productos>  consultar() {
    String sql = "select * from productos";
     ArrayList<Productos> listaProductos = new ArrayList<Productos>();
    try {
        
       // conet = conl.Conexion();
        Connection conet = Conexion.getConexion();
        st = conet.createStatement();
        rs = st.executeQuery(sql);
        Productos productos = new Productos();

        while (rs.next()) {
            productos = new Productos();
            productos.ID = rs.getString("ID");
            productos.Producto = rs.getString("Producto");
            productos.Presentacion = rs.getString("Presentacion");
            productos.Concentracion = rs.getString("Concentracion");
            productos.Stock = Integer.parseInt(rs.getString("Stock"));
            productos.Costo = Double.parseDouble(rs.getString("Costo"));
            listaProductos.add(productos);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return listaProductos;
}

     
}
