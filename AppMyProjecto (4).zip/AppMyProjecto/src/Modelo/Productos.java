/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author el_ca
 */
public class Productos {
    public String ID ;
    public String Producto ;
    public String Presentacion ;
    public String Concentracion ;
    public int Stock ;
    public double Costo ;
}
