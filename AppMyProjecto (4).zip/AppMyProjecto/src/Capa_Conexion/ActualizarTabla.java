/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Capa_Conexion;
import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException; 

/**
 *
 * @author cobra 02020
 */
public class ActualizarTabla {
    
    public static void ActualizarProducto(int cantidadCompra, String ID){
        Conexion cn = new Conexion();

        try { // Establecer la conexión con la base de datos MySQL 
        Connection con = Conexion.getConexion();   
        con = Conexion.getConexion();
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?"; 
        PreparedStatement sentencia = con.prepareStatement(sql); // Establecer los valores de los parámetros 
        sentencia.setInt(1, cantidadCompra); // Restar 1 a la cantidad actual
        sentencia.setString(2, ID); // ID del producto a actualizar // Ejecutar la sentencia de actualización 
        int filasActualizadas = sentencia.executeUpdate(); // Imprimir el número de filas actualizadas 
        con.close(); } catch (SQLException e) 
        { 
        e.printStackTrace(); }
    }
}
       

