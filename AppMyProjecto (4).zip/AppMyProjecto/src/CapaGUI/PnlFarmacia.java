
package CapaGUI;

import static CapaGUI.PnlFarmacia.fechaActual;
import CapaNegocio.EntidadesFarmacia;
import CapaNegocio.EntidadesProductos;
import CapaNegocio.Funciones;
import CapaNegocio.MetodosFarmacia;
import Capa_Conexion.ActualizarTabla;
import Capa_Conexion.Clientes;
import Modelo.Conexion;
import CapaNegocio.ConsultaProducto;
import Modelo.Productos;
import java.awt.BorderLayout;
import java.beans.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;



public class PnlFarmacia extends javax.swing.JPanel {
intProductos prueba = new intProductos();
String titulo[]={"Proveedor","CÓDIGO PRODUCTO","Producto","RUC","Comprobante","Fecha","Presentacion","Concentracion","Stock","Costo","Cantidad","Total"};
String datos[][]={};
DefaultTableModel modtbDatosFarmacia= new DefaultTableModel(datos,titulo);
EntidadesFarmacia farmaciaE = new EntidadesFarmacia();
MetodosFarmacia farmaciaM = new MetodosFarmacia ();
Statement st;
ResultSet rs;


 
 
    public PnlFarmacia() {
        initComponents();
     prueba.setBounds(10, 10, 700, 550);
     tbFarmacia.setModel(modtbDatosFarmacia);
     farmaciaM.llenarProveedor(cboProveedor);
     txtFecha.setText(""+fechaActual());
    
      Funciones funciones = new Funciones();
        ArrayList<Productos> listaPRoductos = funciones.consultar();
        
        funciones.LlenarDataTable(modtbDatosFarmacia ,listaPRoductos);
        
        
        
        
     LlenarClientes();
    }
    
    private void LlenarClientes(){
        ConsultaProducto consultaProducto = new ConsultaProducto();
        ArrayList <Productos> listaClientes = consultaProducto.getProducto();
    }
    
    public static String fechaActual(){
        Date fecha = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/YYYY");
        return formatoFecha.format(fecha);
        
    }

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtTicket = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbFarmacia = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtCODIGO = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        cboListaCoincidencia = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtRUC = new javax.swing.JTextField();
        cboProveedor = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        txtNeto = new javax.swing.JTextField();
        txtSubTotal = new javax.swing.JTextField();
        txtigv = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 255, 204));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REALIZAR COMPRA");

        jPanel4.setBackground(new java.awt.Color(204, 255, 255));

        jLabel17.setText("N° Compra:");

        tbFarmacia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbFarmacia);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos del Producto"));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setText("Medicamento :");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, 30));

        jLabel7.setText("CÓDIGO:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, 30));

        txtStock.setEditable(false);
        jPanel2.add(txtStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 120, -1));

        jLabel9.setText("Stock:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, -1, 30));

        txtCosto.setEditable(false);
        jPanel2.add(txtCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 100, -1));

        jLabel11.setText("Costo c/u");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 80, -1, 30));

        txtCODIGO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCODIGOActionPerformed(evt);
            }
        });
        jPanel2.add(txtCODIGO, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 210, -1));

        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 40, 140, 50));

        cboListaCoincidencia.setEditable(true);
        cboListaCoincidencia.setBorder(null);
        cboListaCoincidencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboListaCoincidenciaActionPerformed(evt);
            }
        });
        jPanel2.add(cboListaCoincidencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, 410, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos de la Compra"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("RUC:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, 40));

        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        jPanel1.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 40, 170, -1));

        jLabel3.setText("Fecha:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 0, -1, 40));

        jLabel4.setText("Proveedor:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 16, -1, 30));

        jLabel5.setText("Comprobante:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 16, -1, 30));
        jPanel1.add(txtRUC, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 130, -1));

        cboProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboProveedorMouseClicked(evt);
            }
        });
        jPanel1.add(cboProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 130, -1));

        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, 120, -1));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setText("CANTIDAD:");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        txtCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadActionPerformed(evt);
            }
        });
        jPanel3.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 90, 40));

        jLabel13.setText("TOTAL:");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));
        jPanel3.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 90, 40));

        btnLimpiar.setText("LIMPIAR");
        jPanel3.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 140, 50));

        btnEliminar.setText("ELIMINAR");
        jPanel3.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 140, 50));

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(txtNeto, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 40, 130, 40));

        txtSubTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSubTotalActionPerformed(evt);
            }
        });
        jPanel5.add(txtSubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, 140, 40));
        jPanel5.add(txtigv, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 130, 40));

        jLabel14.setText("SUB TOTAL");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 20, -1, -1));

        jLabel15.setText("I.G.V");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 20, -1, -1));

        jLabel16.setText("TOTAL A PAGAR");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 20, -1, -1));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 876, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 970, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 950, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 960, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txtTicket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(317, 317, 317)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed


            
            
    }//GEN-LAST:event_btnAgregarActionPerformed

    
    
    
    
    private void txtSubTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSubTotalActionPerformed



    }//GEN-LAST:event_txtSubTotalActionPerformed

    private void cboProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboProveedorMouseClicked

       farmaciaE.setRuc((long) farmaciaM.hallarRuc(cboProveedor.getSelectedItem().toString()));
       txtRUC.setText(""+farmaciaE.getRuc());
        
    }//GEN-LAST:event_cboProveedorMouseClicked

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
    }//GEN-LAST:event_txtFechaActionPerformed
    
    private void txtCODIGOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCODIGOActionPerformed


    
        ConsultaProducto consultaProducto = new ConsultaProducto();
        Productos producto = consultaProducto.getProductoID(txtCODIGO.getText());
        
         cboListaCoincidencia.addItem(producto.Producto);
        txtStock.setText(String.valueOf(producto.Stock));
        txtCosto.setText(String.valueOf(producto.Costo));

    }//GEN-LAST:event_txtCODIGOActionPerformed

    private void cboListaCoincidenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboListaCoincidenciaActionPerformed
       if (evt.getActionCommand().equals("comboBoxEdited")) {
            // La acción fue desencadenada por la entrada de texto del usuario
            String valorIngresado = (String) cboListaCoincidencia.getEditor().getItem();
            if(!valorIngresado.isEmpty()){              
                ConsultaProducto consultaProducto = new ConsultaProducto();
                ArrayList<Productos> productos = consultaProducto.getProductoNombre(valorIngresado);
                cboListaCoincidencia.removeAllItems();
                for (Productos objeto : productos) {
                    cboListaCoincidencia.addItem(objeto.Producto);
                }

                if(productos.size() > 1){
                    cboListaCoincidencia.setPopupVisible(true);
                }else if(productos.size() == 1){

                    for (Productos objeto : productos) {
                        txtCODIGO.setText(String.valueOf(objeto.ID));
                        txtStock.setText(String.valueOf(objeto.Stock));
                        txtCosto.setText(String.valueOf(objeto.Costo));
                    }      //""    ""       
                }
           }else{
                //BORRAR TODAS LAS CASILLAS
            }
        }
    }//GEN-LAST:event_cboListaCoincidenciaActionPerformed

    private void txtCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadActionPerformed
      
        double costo = Double.parseDouble(txtCosto.getText());
        int cantidad = Integer.parseInt(txtCantidad.getText());
        txtTotal.setText( String.valueOf(costo*cantidad) );
        
        
        
    }//GEN-LAST:event_txtCantidadActionPerformed


    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> cboListaCoincidencia;
    private javax.swing.JComboBox<String> cboProveedor;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbFarmacia;
    private javax.swing.JTextField txtCODIGO;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNeto;
    private javax.swing.JTextField txtRUC;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtSubTotal;
    private javax.swing.JTextField txtTicket;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtigv;
    // End of variables declaration//GEN-END:variables
}
