

package CapaGUI;

import CapaNegocio.EntidadesProductos;
import CapaNegocio.Funciones;
import CapaNegocio.MetodosProductos;
import Modelo.Conexion;
import Modelo.Productos;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;



public class PnlProductos extends javax.swing.JPanel {
    MetodosProductos productosP = new MetodosProductos();
    EntidadesProductos entidadesP = new EntidadesProductos();
    Conexion conl = new Conexion();
    Connection conet;
    Statement st;
    ResultSet rs;
 
    String titulo[]={"ID","Producto","Presentacion","Concentracion","Stock","Costo"};
    String datos[][]={};
    DefaultTableModel modtbDatosProducto= new DefaultTableModel(datos,titulo);
    
   int reg;
    
    public PnlProductos() { 
        initComponents();
        tbProductos.setModel(modtbDatosProducto);
      
        Funciones funciones = new Funciones();
        ArrayList<Productos> listaPRoductos = funciones.consultar();
        
        funciones.LlenarDataTable(modtbDatosProducto ,listaPRoductos);
     

    }

  
public void consultar2() {
    String sql = "select * from productos";
    
    try {
        
       // conet = conl.Conexion();
        Connection conet = Conexion.getConexion();
        st = conet.createStatement();
        rs = st.executeQuery(sql);
        Object[] producto = new Object[6]; 
        modtbDatosProducto = (DefaultTableModel)tbProductos.getModel();

        while (rs.next()) {
            producto[0] = rs.getString("ID");
            producto[1] = rs.getString("Producto"); 
            producto[2] = rs.getString("Presentacion"); 
            producto[3] = rs.getString("Concentracion");
            producto[4] = rs.getInt("Stock");
            producto[5] = rs.getDouble("Costo");
            modtbDatosProducto.addRow(producto);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}



 void Agregar() {
    entidadesP.setProducto(txtProducto.getText());
    entidadesP.setPresentacion(txtPresentacion.getText());
    entidadesP.setConcentracion(txtConcentracion.getText());
    entidadesP.setStock((int) jspStock.getValue());
    entidadesP.setCosto(Double.parseDouble(txtCosto.getText()));
    entidadesP.setID(productosP.HallarCodigo(entidadesP.getProducto(), entidadesP.getPresentacion(), entidadesP.getConcentracion()));
    txtID.setText(entidadesP.getID());
    
    try {
        if (entidadesP.getID().equals("") &&
            entidadesP.getProducto().equals("") && 
            entidadesP.getPresentacion().equals("") && 
            entidadesP.getConcentracion().equals("") && 
            entidadesP.getStock() == 0 && 
            entidadesP.getCosto() > 0) {
            JOptionPane.showMessageDialog(null, "producto fallido");    
        } else {
            String sql = "INSERT INTO productos (ID, Producto, Presentacion, Concentracion, Stock, Costo) " +
                         "VALUES ('" + entidadesP.getID() + "', '" + 
                                      entidadesP.getProducto() + "', '" + 
                                      entidadesP.getPresentacion() + "', '" +
                                      entidadesP.getConcentracion() + "', " +
                                      entidadesP.getStock() + ", " +
                                      entidadesP.getCosto() + ")";
            conet = Conexion.getConexion();
            st = conet.createStatement();
            st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Nuevo producto");
            consultar2();        
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtConcentracion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jspStock = new javax.swing.JSpinner();
        txtPresentacion = new javax.swing.JTextField();
        txtProducto = new javax.swing.JTextField();
        txtID = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbProductos = new javax.swing.JTable();
        btnCancelar = new javax.swing.JButton();
        btnAgregarProductos = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Ingresar Producto");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(124, 0, 100, 40));

        jLabel2.setText("Ingresar Presentación");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 120, 20));
        jPanel1.add(txtCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 70, 80, -1));

        jLabel3.setText("Costo");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, -1, -1));

        jLabel4.setText("Ingresar Concentración");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 10, -1, -1));
        jPanel1.add(txtConcentracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 10, 80, -1));

        jLabel5.setText("Stock");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, -1, -1));
        jPanel1.add(jspStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 90, -1));
        jPanel1.add(txtPresentacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, 130, -1));
        jPanel1.add(txtProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 130, -1));

        txtID.setEditable(false);
        jPanel1.add(txtID, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 90, -1));

        jLabel7.setText("ID");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 840, 100));

        tbProductos.setBackground(new java.awt.Color(204, 204, 255));
        tbProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbProductos);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 790, 240));

        btnCancelar.setText("CANCELAR STOCK");
        add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 210, 150, 30));

        btnAgregarProductos.setText("AGREGAR STOCK");
        btnAgregarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarProductosActionPerformed(evt);
            }
        });
        add(btnAgregarProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 210, 150, 30));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("INGRESAR PRODUCTOS");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarProductosActionPerformed
        
        Agregar();
        consultar2();
        
  

    }//GEN-LAST:event_btnAgregarProductosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarProductos;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jspStock;
    private javax.swing.JTable tbProductos;
    private javax.swing.JTextField txtConcentracion;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtPresentacion;
    private javax.swing.JTextField txtProducto;
    // End of variables declaration//GEN-END:variables
}
